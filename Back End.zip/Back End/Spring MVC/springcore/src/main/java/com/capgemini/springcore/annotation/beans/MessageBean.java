package com.capgemini.springcore.annotation.beans;

public class MessageBean {
	private String message;

	//Getters and setters
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}// End of class
