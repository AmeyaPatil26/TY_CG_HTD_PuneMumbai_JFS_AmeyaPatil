package com.capgemini.springcore.interfaces;

public interface Animal {

	public void eat();
	public void speak();
	public void walk();
}//End of Animal interface
