package com.capgemini.springcore.beans;

public class DepartmentBean {

	private int deptId;
	private String deptName;
	
	//Getters and setters
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	
}//End of class
