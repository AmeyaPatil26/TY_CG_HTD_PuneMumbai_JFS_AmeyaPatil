package com.capgemini.springcore.beans;

public class MobileDisplayBean {
	 
	private double displaySize;
	private int resolution;
	
	//Getter and setter
	
	public double getDisplaySize() {
		return displaySize;
	}
	public void setDisplaySize(double displaySize) {
		this.displaySize = displaySize;
	}
	public int getResolution() {
		return resolution;
	}
	public void setResolution(int resolution) {
		this.resolution = resolution;
	}
	
	
	

}
