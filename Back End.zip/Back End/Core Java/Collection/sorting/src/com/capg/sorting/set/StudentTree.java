package com.capg.sorting.set;

import java.util.TreeSet;



public class StudentTree {

	public static void main(String[] args) {
		
		TreeSet<Student> ts=new TreeSet<Student>();
		
	}

}
