package com.capg.map.student;

public class Student {

	public int id;
	public	String name;
	public double percentage;
	char gender;
	
	public Student(int id, String name, double percentage, char gender) {
		this.id = id;
		this.name = name;
		this.percentage = percentage;
		this.gender = gender;
	}
	
	public Student() {
		
	}
}
