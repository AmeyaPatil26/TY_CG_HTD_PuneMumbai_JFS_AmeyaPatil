package com.capgemini.ArrayPrg.list;

public class StudentDis {

	int id;
	String name;
	double percentage;
	public StudentDis(int id, String name, double percentage) {
	
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}
	
}
