package com.capgemini.ArrayPrg.list;

import java.util.Scanner;

public class TestMyStudent {

	public static void main(String[] args) {
		
		MyStudentApp m=new MyStudentApp();
		Scanner sc=new Scanner(System.in);
		while(true){
			
			System.out.println("Enter the option /n 1.Add /n 2.Display /n 3.exit");
			int opt=sc.nextInt();
			
			switch(opt) {
			case 1: m.add();
					break;
			case 2: m.
			
			
			}
		}
		
		
		
	}
}
