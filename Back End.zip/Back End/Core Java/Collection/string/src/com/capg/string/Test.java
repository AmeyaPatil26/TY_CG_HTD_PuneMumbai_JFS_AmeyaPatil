package com.capg.string;

public class Test {
	public static void main(String[] args) {
		String k= "divya";
		String t="raju";
		String m="divya";
		System.out.println(" k is "+k);
		System.out.println("m is "+m);
}

}
