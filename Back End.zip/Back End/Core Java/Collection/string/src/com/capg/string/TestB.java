package com.capg.string;

public class TestB {
public static void main(String[] args) {
	StringBuilder sb=new StringBuilder();
	sb.append("Priya");
	System.out.println(sb);
	sb.append("om");
	System.out.println(sb);
}
}
