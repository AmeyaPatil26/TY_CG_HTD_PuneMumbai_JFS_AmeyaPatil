package com.capg.string;

public interface Nak {
	default void test() {}
static void tu() {}

}
