package com.capg.exception.first;

import java.io.File;
import java.io.IOException;

public class TestE {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f = new File("viky.txt");
		
		f.createNewFile();

	}

}
