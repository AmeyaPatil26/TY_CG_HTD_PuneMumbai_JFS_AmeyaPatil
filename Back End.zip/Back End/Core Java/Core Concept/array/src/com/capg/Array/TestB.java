package com.capg.Array;

public class TestB {

	public static void main(String[] args) {
		int []i= chinnu();
		for(int k:i) {
			System.out.println(k);
		}
		
	}

	 static int[] chinnu() {
int []a= {10,20,40,60};
		return a;
	}
}
