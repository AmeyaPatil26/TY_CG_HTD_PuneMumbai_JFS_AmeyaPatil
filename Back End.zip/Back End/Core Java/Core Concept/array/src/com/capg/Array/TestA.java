package com.capg.Array;

public class TestA {
public static void main(String[] args) {
	int []m= {10,20,30,40};
	recive(m);
}
 static void recive(int []a)
 {
	 for(int i: a) {
		 System.out.println(i);
	 }
 }
}
