package com.capg.Array;

public class Example {
	public static void main(String[] args) {
		char ch[]= {'A','P','P','L','E'};
		
		for(char a: ch) {
			System.out.println(a);
		}
		
		double a[]= new double[4];
		a[2]=100;
		for(double i :a)
		{
			System.out.println(i);
		}
	}

}
