package com.capg.Array;

public interface Sqr {
int square(int i);
}
