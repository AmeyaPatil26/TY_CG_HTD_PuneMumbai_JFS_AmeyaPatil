package com.capg.Array;

public interface Sum {
	int add(int a,int b);

}
