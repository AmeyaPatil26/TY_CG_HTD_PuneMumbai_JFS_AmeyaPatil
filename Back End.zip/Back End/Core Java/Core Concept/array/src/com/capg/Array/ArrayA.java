package com.capg.Array;

public class ArrayA {
	public static void main(String[] args) {
		double [] a= new double[4];
		a[0]=24;
		a[3]=19;
		a[1]=15;
		a[2]=6;
		
		
		for(int i=0;i<4;i++)
		{
			System.out.println(a[i]);
		}
	}
	

}
