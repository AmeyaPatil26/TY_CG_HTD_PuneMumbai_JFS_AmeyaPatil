package com.capg.Array;

public class TestSqr {

	public static void main(String[] args) {
		Sqr i = (a) -> a * a;
		int j = i.square(5);
		System.out.println("square is " + j);

	}

}
