package com.capg.Array;

public class TestL {

	public static void main(String[] args) {
Sum f=(a,b)-> a+b;
int j=f.add(20, 60);
System.out.println("sum is"+j);
	}

}
