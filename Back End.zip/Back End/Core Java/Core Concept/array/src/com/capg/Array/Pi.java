package com.capg.Array;

interface PiExpres{
double  getValue();
}
public class Pi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PiExpres i=( )->{
			double pi=3.142;
			return pi;
		}
		
	
	}

}
