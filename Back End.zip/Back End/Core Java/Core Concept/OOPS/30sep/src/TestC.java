
public class TestC {

	public static void main(String[] args) {
 Train t=new Train();
 t.search(35672);
 t.search("exp");
	}

}
