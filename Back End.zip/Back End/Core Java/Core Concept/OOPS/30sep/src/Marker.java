
public class Marker {
	void write() {
		System.out.println("Write method");
	}

	void color() {
		System.out.println("color method");
	}
}
