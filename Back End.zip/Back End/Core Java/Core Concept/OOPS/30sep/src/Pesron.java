
public class Pesron {
	int i = 100;
	Marker m = new Marker();

	void walk() {
		System.out.println("walking");
	}
}
