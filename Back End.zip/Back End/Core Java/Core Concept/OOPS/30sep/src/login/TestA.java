package login;

public class TestA {

	public static void main(String[] args) {
Fb f=new Fb();
f.login(545541, "pjsdldnk");
	}

}
