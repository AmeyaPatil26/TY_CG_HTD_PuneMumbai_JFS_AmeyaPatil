package login;

public class Fb {
	final void login(String name,String pwd)
	{
		System.out.println("by name and pwd");
	}

	void login(long num,String pwd)
	{
		System.out.println("by number and pwd");
	}
}
