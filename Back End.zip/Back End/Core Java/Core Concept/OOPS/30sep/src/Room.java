public class Room {

	static int k=200;
	static Fan f=new Fan();
}
