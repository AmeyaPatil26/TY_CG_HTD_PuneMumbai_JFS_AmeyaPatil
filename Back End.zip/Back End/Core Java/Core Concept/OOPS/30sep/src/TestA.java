
public class TestA {

	public static void main(String[] args) {
Pesron p=new Pesron();
System.out.println(p.i);
p.walk();
p.m.color();
p.m.write();
	}

}
