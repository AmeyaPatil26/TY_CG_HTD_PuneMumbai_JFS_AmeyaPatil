
public class Fan {
void on() {
	System.out.println("on method");
}
void off() {
	System.out.println("off method");
}
}
