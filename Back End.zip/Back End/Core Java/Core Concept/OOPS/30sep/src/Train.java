
public class Train {
void search(String name) {
	System.out.println("Seach train by name");
}
void search(int num)
{
	System.out.println("search by number");
	}
}

