package com.capg.corejava.cfs;

public class IfExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 12;
		int j=5;
		if (i < 10) 
		{
			System.out.println("i is single digit");
		}
		else {
			System.out.println("i is not a single digit");
		}
		if (j < 10) 
		{
			System.out.println("j is single digit");
		}
		else {
			System.out.println("j is not a single digit");
		}
		System.out.println("Execution Completed");
	}

}
