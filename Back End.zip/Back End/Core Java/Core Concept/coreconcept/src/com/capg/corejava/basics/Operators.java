package com.capg.corejava.basics;

public class Operators {
	public static void main(String[] args) {
		int i = 10; //declare and initialize i
		int j = 20;
		int res = i + j; // Addition
		System.out.println("i+j=" + res);
		res = i - j; // Subtraction
		System.out.println("i-j=" + res);
		res = i * j; // multiplication
		System.out.println("i*j=" + res);
		res = i / j; // Division
		System.out.println("i/j=" + res);
		res = i % j; // Modulus
		System.out.println("i%j=" + res);
		
	}

}
