package com.capg.corejava.nwstart;

public class Lays implements Chips {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("im openning lays");
		
	}

	@Override
	public void eat() {
		System.out.println("im eat lays");
		
	}

}
