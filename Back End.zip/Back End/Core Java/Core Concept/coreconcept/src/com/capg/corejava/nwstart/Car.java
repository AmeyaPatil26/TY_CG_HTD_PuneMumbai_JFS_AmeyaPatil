package com.capg.corejava.nwstart;

public class Car {
	void move()
	{
		System.out.println("i am mov() method");
	}
	}
