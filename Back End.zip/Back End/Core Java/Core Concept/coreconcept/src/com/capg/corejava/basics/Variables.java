package com.capg.corejava.basics;

public class Variables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte b= -128;  //declaration and initialization of byte
		short s= 101; //declaration and initialization of short
		int i =101; //declaration and initialization of integer
		float f = 101.015575888865398f; //declaration and initialization of float
		long l= 10L; //declaration and initialization of long
		double d= 13.45656564985616458; //declaration and initialization of double
		char ch= 'A'; //declaration and initialization of char
		boolean g= true; //declaration and initialization of boolean
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(f);
		System.out.println(l);
		System.out.println(d);
		System.out.println(ch);
		System.out.println(g);

	}

}
