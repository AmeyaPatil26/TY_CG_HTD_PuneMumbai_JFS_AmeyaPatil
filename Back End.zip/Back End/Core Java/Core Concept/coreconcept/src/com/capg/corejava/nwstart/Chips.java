package com.capg.corejava.nwstart;

public interface Chips {
	void open();
	void eat();
	

}
