package com.capg.corejava.loop;

public class ForLoopExample {

	public static void main(String[] args) {

		int i=5;
			if(i%2==0){
				for(i=1;i<=10;i++)
				System.out.println("i is even");
			}
			else {
			System.out.println("i is odd");}

	}

}
