package com.capg.corejava.inheritance;

public abstract class Demo {
	public abstract void print();
	//if the abstract  method then class should be abstract
	//but it not necessary to write the abstract keyword for method abstract class
	
}
