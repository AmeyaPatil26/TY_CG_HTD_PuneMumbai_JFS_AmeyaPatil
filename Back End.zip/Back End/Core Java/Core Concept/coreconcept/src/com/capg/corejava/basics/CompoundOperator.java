package com.capg.corejava.basics;

public class CompoundOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 10;
		int j = 20;
		j += i;
		System.out.println(j);
		j -= i;
		System.out.println(j);
		j *= i;
		System.out.println(j);
		j /= i;
		System.out.println(j);
		j %= i;
		System.out.println(j);
	}

}
