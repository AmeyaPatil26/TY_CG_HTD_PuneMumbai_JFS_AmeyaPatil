package com.capg.corejava.Abstraction;

public class Marker extends Pen {
 double size;
 void color() {
	 System.out.println("color ");
	 
 }
}
