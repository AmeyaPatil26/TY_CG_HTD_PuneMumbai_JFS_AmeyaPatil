package com.capg.corejava.nwstart;

class Driver {

	void recive(Car c) {
		c.move();
	}

}
