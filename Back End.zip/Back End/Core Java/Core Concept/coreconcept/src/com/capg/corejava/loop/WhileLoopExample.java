package com.capg.corejava.loop;

public class WhileLoopExample {

	public static void main(String[] args) {
		int i=5;
	
		
		  while(i<=16) { 
			  System.out.println(i);
		  i++; }
		   System.out.println("Outside");
		 
		/*
		 * while(true)    it goes infinite error
		 *  { 
		 *  System.out.println(i);
		 *   i++; }
		 *   System.out.println("Outside");
		 */
		   
	}

}
