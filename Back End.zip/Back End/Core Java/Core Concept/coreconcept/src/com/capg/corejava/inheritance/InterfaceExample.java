package com.capg.corejava.inheritance;

public interface InterfaceExample {
	
	
	public void display();
	public void show();
//marker interface no of abstract method 
}
