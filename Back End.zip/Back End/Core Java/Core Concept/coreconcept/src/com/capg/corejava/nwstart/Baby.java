package com.capg.corejava.nwstart;

public class Baby {
	void recive(Chips c) {
		c.open();
		c.eat();
		
	}

}
