package com.capg.corejava.nwstart;

public class Bingo implements Chips {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("im openning bingo");
		
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("im eating bingo");
		
	}

}
