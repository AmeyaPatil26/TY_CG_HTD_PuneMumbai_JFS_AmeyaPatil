package com.capg.corejava.nwstart;

public class TestA {
	public static void main(String [] args) {
		Car i=new Car();
		Driver d=new Driver();
		d.recive(i);
	}

}
