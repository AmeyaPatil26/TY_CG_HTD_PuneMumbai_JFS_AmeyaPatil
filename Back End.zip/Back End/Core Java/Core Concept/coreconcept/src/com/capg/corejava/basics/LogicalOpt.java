package com.capg.corejava.basics;

public class LogicalOpt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		int j=20;
		System.out.println(i>j && j>i);

	}

}
