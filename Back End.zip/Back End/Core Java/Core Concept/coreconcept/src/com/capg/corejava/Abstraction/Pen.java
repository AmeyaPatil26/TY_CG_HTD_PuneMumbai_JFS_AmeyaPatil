package com.capg.corejava.Abstraction;

public class Pen {
	int cost;
	void write() {
		System.out.println("write");
	}

}
