package com.capg.corejava.nwstart;

public class TestB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lays r =new Lays();
		Baby b=new Baby();
		b.recive(r);

	}

}
