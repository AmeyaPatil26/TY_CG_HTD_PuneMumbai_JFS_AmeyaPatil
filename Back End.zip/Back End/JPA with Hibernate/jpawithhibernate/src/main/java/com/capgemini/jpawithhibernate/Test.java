package com.capgemini.jpawithhibernate;

public class Test {

	public static void main(String[] args) {

		
	}//end of the main

}//End of the class
